Ring Video Doorbell
=========

Add on for Kodi to view doorbell recordings saved on ring.com. 

**Requires a ring.com subscription**

- Supports playback of recorded events from ring.com for doorbell, floodlight and stickup cams.

Credits
===========

Kodi add-on created by [jlippold](https://github.com/jlippold/) using python libraries created by [tchellomello](https://github.com/tchellomello/)

