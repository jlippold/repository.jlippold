Add on for Kodi to view doorbell recordings saved on ring.com


Credits
===========

Kodi add-on created by [jlippold](https://github.com/jlippold/) using python libraries created by [tchellomello](https://github.com/tchellomello/)

